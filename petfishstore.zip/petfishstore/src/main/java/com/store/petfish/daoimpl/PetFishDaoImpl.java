package com.store.petfish.daoimpl;

public class PetFishDaoImpl {

	
}
