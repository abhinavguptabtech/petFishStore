package com.store.petfish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetfishstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetfishstoreApplication.class, args);
	}

}
