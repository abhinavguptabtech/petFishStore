package com.store.petfish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetfishstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
